export * from './RemovePrefixModule.js';
export * from './ResourceAdderModule.js';
export * from './PatronSearchModule.js';
export * from './KeyboardShortcutsModule.js';
export * from './WhatsNewModule.js';
export * from './CommitModule.js';